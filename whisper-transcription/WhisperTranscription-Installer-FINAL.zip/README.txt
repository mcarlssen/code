Whisper Transcription Installer
==============================

This is a streamlined installer package for Whisper Transcription.

INSTALLATION:
1. Right-click "install.bat" and select "Run as administrator"
2. Follow the on-screen prompts
3. After installation, right-click any audio file and select "Whisper Transcribe"

FEATURES:
- Automatic transcription of audio files (WAV, MP3, M4A, AAC, FLAC, OGG, WMA)
- Context menu integration (right-click "Whisper Transcribe")
- Multiple Whisper model support (tiny, base, small, medium, large)
- Clean, professional output with clipboard integration
- Automatic dependency installation (FFmpeg, Whisper.cpp)

UNINSTALLATION:
- Use the uninstaller created during installation
- Or run "UNINSTALL.bat" from the installation directory

For more information, see the full documentation in the main directory.
